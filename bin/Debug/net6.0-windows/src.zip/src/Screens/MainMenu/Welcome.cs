﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static Top_Seguros_Brasil_Desktop.Home;


namespace Top_Seguros_Brasil_Desktop
{
    public partial class Welcome : UserControl 
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void Welcome_VisibleChanged(object sender, EventArgs e)
        {
            

        }
    }
}
